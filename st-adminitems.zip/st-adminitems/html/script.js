let itemList = [];

window.addEventListener('message', (event) => {
  if (event.data.type === "open") {
    document.body.style.display = "block";
  }

  if (event.data.type === "loadItems") {
    itemList = event.data.items;
    renderItemList(itemList);
  }
});

function renderItemList(items) {
  const container = document.getElementById("items-list");
  container.innerHTML = "";

  items.forEach(item => {
    const card = document.createElement("div");
    card.className = "item";

    const image = document.createElement("img");
    image.src = `nui://qb-inventory/html/images/${item.name}.png`;
    image.alt = item.label;
    image.onerror = () => {
      image.src = 'nui://qb-inventory/html/images/unknown.png';
    };

    const label = document.createElement("span");
    label.textContent = item.label;

    card.appendChild(image);
    card.appendChild(label);

    card.addEventListener('click', () => selectItem(item));

    container.appendChild(card);
  });
}

function filterItems() {
  const input = document.getElementById("search").value.toLowerCase();
  const filtered = itemList.filter(i => i.name.toLowerCase().includes(input) || i.label.toLowerCase().includes(input));
  renderItemList(filtered);
}

function selectItem(item) {
  const section = document.getElementById("selected-item");
  section.style.display = "block";
  section.dataset.item = item.name;

  const image = document.getElementById("item-img");
  image.src = `nui://qb-inventory/html/images/${item.name}.png`;
}

function giveItem() {
  const itemName = document.getElementById("selected-item").dataset.item;
  const amount = document.getElementById("amount").value;

  fetch(`https://${GetParentResourceName()}/giveItem`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ item: itemName, amount: parseInt(amount) })
  });
}

function closeUI() {
  document.body.style.display = "none";
  fetch(`https://${GetParentResourceName()}/close`, {
    method: 'POST'
  });
}
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    // إخفاء الواجهة
    const container = document.querySelector('items-list');
    container.classList.remove('active');

    // إرسال حدث للسيرفر لإغلاق الواجهة
    fetch(`https://${GetParentResourceName()}/close`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
  }
});
