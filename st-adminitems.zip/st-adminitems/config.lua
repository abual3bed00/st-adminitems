Config = {}
Config.AdminGroups = {
    admin = true,
    dev = true
}