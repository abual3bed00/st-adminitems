local isAdmin = false

RegisterNetEvent("st-adminitem:setAdmin", function(status)
    isAdmin = status
    print("[CLIENT] Admin status set to:", status)
end)


RegisterNetEvent("st-adminitem:sendItems", function(data)
    print("Received items from server:", json.encode(data))  -- طباعة العناصر المستلمة
    SendNUIMessage({
        type = "loadItems",
        items = data
    })
end)

RegisterCommand("giveitemui", function()
    TriggerServerEvent("st-adminitem:openUI")
end)

RegisterKeyMapping("giveitemui", "Admin Item Giver UI", "keyboard", "F7")

RegisterNetEvent("st-adminitem:open", function(items)
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "open"
    })
    SendNUIMessage({
        type = "loadItems",
        items = items
    })
end)

RegisterNUICallback("giveItem", function(data, cb)
    if data.item and data.amount then
        TriggerServerEvent("st-adminitem:give", data.item, tonumber(data.amount))
    end
    cb({})
end)

RegisterNUICallback("close", function(_, cb)
    SetNuiFocus(false, false)
    cb({})
end)
