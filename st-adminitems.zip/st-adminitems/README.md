# stdev | ii_abual3bed discord: https://dscord.gg/7c2gZqD98A
# st-adminitems - QBCore

واجهة NUI مكتاملة لاعطاء الايتمات .


---

## 📦 المميزات / Features

- ✅ فتح الواجهة عن طريق امر مخصص و زر مخصص .
- ✅ عرض كل الايتمات من الكور مع صورها .
- ✅ صلاحيات محددة (admin / dev).
- ✅ تحديث الكمية .
- ✅ نظام بحث ديناميكي .
- ✅ متوافق مع QBCore Framework.
---
##  التحكم / Controls

1 - giveitemui

2 - F7

---
## 🛠️ التركيب / Installation

1. ضع السكربت داخل مجلد `resources/[qb]/st-adminitems`
2. تأكد من أن ملفات `client.lua`, `server.lua`, و `html` مضافة بشكل صحيح.
3. أضف السكربت في `server.cfg`:

```cfg
ensure st-adminitems

