QBCore = exports['qb-core']:GetCoreObject()

Config = {}
Config.AdminGroups = {
    admin = true,
    dev = true
}

local function isPlayerAdmin(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then
        print("[AdminCheck] Player not found")
        return false
    end

    local job = Player.PlayerData.job.name
    print("[AdminCheck] Player job is:", job)

    return Config.AdminGroups[job] == true
end

RegisterNetEvent("st-adminitem:openUI", function()
    local src = source

    if not isPlayerAdmin(src) then
        TriggerClientEvent('QBCore:Notify', src, "You are not an admin!", "error")
        return
    end

    local items = {}
    for k, v in pairs(QBCore.Shared.Items) do
        items[#items + 1] = {
            name = v.name,
            label = v.label or v.name
        }
    end

    TriggerClientEvent("st-adminitem:open", src, items)
end)

RegisterNetEvent("st-adminitem:give", function(item, amount)
    local src = source
    if not isPlayerAdmin(src) then
        TriggerClientEvent('QBCore:Notify', src, "You are not an admin!", "error")
        return
    end

    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        Player.Functions.AddItem(item, amount or 1)
        TriggerClientEvent('QBCore:Notify', src, 'You have been given: ' .. item .. ' x ' .. amount, 'success')
    end
end)
